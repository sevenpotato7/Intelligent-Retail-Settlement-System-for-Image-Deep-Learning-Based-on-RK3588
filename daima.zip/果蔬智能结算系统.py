import tkinter as tk
from tkinter import ttk, messagebox
import time
import random
import cv2
import numpy as np
import onnxruntime as ort
from PIL import Image, ImageTk
import os
import sys

class HX711_sysfs:
    def __init__(self, data_gpio=90, clock_gpio=93):
        self.data_gpio = data_gpio
        self.clock_gpio = clock_gpio
        # 导出并初始化GPIO引脚
        self._export_gpio(data_gpio)
        self._export_gpio(clock_gpio)
        self._set_direction(data_gpio, "in")
        self._set_direction(clock_gpio, "out")
        self._set_value(clock_gpio, 0)
        
        # 校准参数
        self.offset = 0
        self.scale = 1.0
        self.reference_unit = 1.0

    def _export_gpio(self, gpio):
        """导出GPIO引脚"""
        gpio_path = f"/sys/class/gpio/gpio{gpio}"
        if not os.path.exists(gpio_path):
            with open("/sys/class/gpio/export", "w") as f:
                f.write(str(gpio))
            time.sleep(0.1)

    def _set_direction(self, gpio, direction):
        with open(f"/sys/class/gpio/gpio{gpio}/direction", "w") as f:
            f.write(direction)

    def _set_value(self, gpio, value):
        with open(f"/sys/class/gpio/gpio{gpio}/value", "w") as f:
            f.write(str(value))

    def _get_value(self, gpio):
        with open(f"/sys/class/gpio/gpio{gpio}/value", "r") as f:
            return int(f.read().strip())

    def read_raw(self):
        """读取原始24位ADC值"""
        start_time = time.time()
        while self._get_value(self.data_gpio) != 0:
            if time.time() - start_time > 1.0:
                return 0
            time.sleep(0.001)
        
        # 读取24位数据
        value = 0
        for i in range(24):
            self._set_value(self.clock_gpio, 1)
            time.sleep(0.00001)
            value <<= 1
            self._set_value(self.clock_gpio, 0)
            time.sleep(0.00001)
            if self._get_value(self.data_gpio):
                value |= 1
        
        # 第25个脉冲切换通道
        self._set_value(self.clock_gpio, 1)
        time.sleep(0.00001)
        value ^= 0x800000  # 转换补码
        self._set_value(self.clock_gpio, 0)
        time.sleep(0.00001)
        
        return value

    def read_average(self, times=5):
        """读取多次平均值"""
        values = []
        for _ in range(times):
            values.append(self.read_raw())
            time.sleep(0.05)
        return sum(values) / len(values)

    def get_value(self, times=5):
        """获取原始值（减去偏移量）"""
        return self.read_average(times) - self.offset

    def get_weight(self, times=5):
        """获取重量值（克）"""
        return self.get_value(times) * self.scale

    def tare(self, times=5):
        """去皮（归零）"""
        self.offset = self.read_average(times)

    def calibrate(self, known_weight, times=10):
        """校准传感器"""
        self.tare(times)
        raw_value = self.read_average(times)
        self.scale = known_weight / (raw_value - self.offset)

class FruitVegScaleApp:
    def __init__(self, root):
        self.root = root
        self.root.title("智能果蔬称重系统")
        self.root.geometry("1200x800")
        self.root.configure(bg='#f5f5f5')
        
     
        self.initialize_model()
        

        self.cap = self.initialize_camera()
        if not self.cap:
            return
            
   
        self.sensor = self.initialize_sensor()
        
        self.setup_styles()
        self.current_item = None
        self.items = {
            "苹果": 12.8, "香蕉": 9.5, "橙子": 8.2, 
            "西红柿": 6.5, "黄瓜": 5.0, "草莓": 25.0, "葡萄": 15.0
        }
        self.weight = 0.0
        self.total_price = 0.0
        self.frame_count = 0
        self.start_time = time.time()
        
        # 创建UI界面
        self.create_ui()

        self.update_camera()
        self.update_weight()
    
    def initialize_camera(self):
        camera_devices = [0, 21, 22, 23]
        for device in camera_devices:
            try:
                cap = cv2.VideoCapture(device)
                if cap.isOpened():
                    ret, frame = cap.read()
                    if ret:
                        cap.set(cv2.CAP_PROP_FRAME_WIDTH, 1280)
                        cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 720)
                        return cap
                    cap.release()
            except Exception:
                pass
        messagebox.showerror("错误", "无法打开任何摄像头设备")
        self.root.destroy()
        return None
    
    def initialize_sensor(self):
        """初始化称重传感器"""
        try:
            sensor = HX711_sysfs(data_gpio=104, clock_gpio=115)
            sensor.tare()  # 自动去皮
            return sensor
        except Exception as e:
            print(f"称重传感器初始化失败: {str(e)}")
            messagebox.showwarning("警告", "称重传感器初始化失败，将使用模拟数据")
            return None
    
    def initialize_model(self):
        """初始化ONNX模型"""
        model_path = "best.onnx"
        try:
            # 创建推理会话
            providers = ['CPUExecutionProvider']
            self.sess = ort.InferenceSession(model_path, providers=providers)
            self.input_name = self.sess.get_inputs()[0].name
            self.output_name = self.sess.get_outputs()[0].name
            
            # 类别标签 - 使用中文名称
            self.classes = [
                '苹果', '香蕉', '甜菜根', '甜椒', '卷心菜', '辣椒', 
                '胡萝卜', '花椰菜', '辣椒', '玉米', '黄瓜', 
                '茄子', '大蒜', '生姜', '葡萄', '墨西哥辣椒', '猕猴桃', 
                '柠檬', '生菜', '芒果', '洋葱', '橙子', '红椒', 
                '梨', '豌豆', '菠萝', '石榴', '土豆', '萝卜', 
                '黄豆', '菠菜', '甜玉米', '红薯', '西红柿', 
                '芜菁', '西瓜'
            ]
            self.model_loaded = True
        except Exception:
            self.model_loaded = False
            messagebox.showwarning("警告", "物体检测模型加载失败，将使用模拟数据")
    
    def setup_styles(self):
        """配置自定义样式"""
        style = ttk.Style()
        style.configure('Custom.TFrame', background='#f5f5f5')
        style.configure('Custom.TLabelframe', background='#f5f5f5', 
                       bordercolor='#ddd', borderwidth=2, relief='solid',
                       labelfont=('Microsoft YaHei', 10, 'bold'))
        style.configure('Title.TLabel', font=('Microsoft YaHei', 16, 'bold'),
                      background='#f5f5f5', foreground='#2c3e50')
        style.configure('Time.TLabel', font=('Microsoft YaHei', 16),
                      background='#f5f5f5', foreground="#0d0f0f")
        style.configure('Info.TLabel', font=('Microsoft YaHei', 24),
                      background='#f5f5f5', foreground='#34495e')
        style.configure('Total.TLabel', font=('Microsoft YaHei', 24, 'bold'),
                      background='#f5f5f5', foreground='#e74c3c')
        style.configure('Hint.TLabel', font=('Microsoft YaHei', 12),
                      background='#f5f5f5', foreground='#7f8c8d')
        style.configure('Accent.TButton', font=('Microsoft YaHei', 24, 'bold'),
                      foreground='red', background='#3498db')
        style.map('Accent.TButton', 
                 background=[('active', '#2980b9'), ('pressed', '#1a5276')])
        style.configure('Settings.TButton', font=('Microsoft YaHei', 10),
                      foreground='#34495e', background='#ecf0f1')
        style.map('Settings.TButton',
                background=[('active', '#bdc3c7'), ('pressed', '#95a5a6')])
    
    def create_ui(self):
        """创建用户界面"""
        # 系统状态区
        self.status_frame = ttk.Frame(self.root, style='Custom.TFrame')
        self.status_frame.pack(fill=tk.X, padx=10, pady=10)
        
        self.title_label = ttk.Label(self.status_frame, text="智能果蔬称重系统", 
                                   style='Title.TLabel')
        self.title_label.pack(side=tk.LEFT)
        
        self.time_label = ttk.Label(self.status_frame, text="", 
                                  style='Time.TLabel')
        self.time_label.pack(side=tk.RIGHT)
        self.update_time()
        
        # 主内容区
        self.main_frame = ttk.Frame(self.root, style='Custom.TFrame')
        self.main_frame.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0,10))
        
        # 左侧图像显示区
        self.image_frame = ttk.LabelFrame(self.main_frame, text="图像识别区", 
                                        style='Custom.TLabelframe')
        self.image_frame.pack(side=tk.LEFT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        self.canvas = tk.Canvas(self.image_frame, bg='#000000', highlightthickness=0)
        self.canvas.pack(fill=tk.BOTH, expand=True)
        
        self.hint_label = ttk.Label(self.image_frame, 
                                  text="请将果蔬放置于摄像头前，确保图像清晰",
                                  style='Hint.TLabel')
        self.hint_label.pack(side=tk.BOTTOM, pady=5)
        
        # 右侧功能区
        self.right_paned = ttk.PanedWindow(self.main_frame, orient=tk.VERTICAL)
        self.right_paned.pack(side=tk.RIGHT, fill=tk.BOTH, expand=True, padx=5, pady=5)
        
        # 信息展示区
        self.info_frame = ttk.LabelFrame(self.right_paned, text="商品信息", 
                                       style='Custom.TLabelframe')
        self.info_frame.pack(fill=tk.BOTH, expand=True)
        self.right_paned.add(self.info_frame, weight=1)
        
        self.item_label = ttk.Label(self.info_frame, text="品类：未识别", 
                                   style='Info.TLabel')
        self.item_label.pack(anchor=tk.W, pady=8, padx=10)
        
        self.price_label = ttk.Label(self.info_frame, text="单价：0.00 元/kg", 
                                   style='Info.TLabel')
        self.price_label.pack(anchor=tk.W, pady=8, padx=10)
        
        self.weight_label = ttk.Label(self.info_frame, text="重量：0.000 kg", 
                                    style='Info.TLabel')
        self.weight_label.pack(anchor=tk.W, pady=8, padx=10)
        
        # 结算操作区
        self.payment_frame = ttk.LabelFrame(self.right_paned, text="结算", 
                                         style='Custom.TLabelframe')
        self.payment_frame.pack(fill=tk.BOTH, expand=True)
        self.right_paned.add(self.payment_frame, weight=1)
        
        self.total_label = ttk.Label(self.payment_frame, text="总价：0.00 元", 
                                   style='Total.TLabel')
        self.total_label.pack(pady=15)
        
        self.pay_button = ttk.Button(self.payment_frame, text="确认支付", 
                                   style='Accent.TButton', 
                                   command=self.process_payment)
        self.pay_button.pack(pady=20, ipadx=40, ipady=10)
        
        # 底部功能区
        self.bottom_frame = ttk.Frame(self.root, style='Custom.TFrame')
        self.bottom_frame.pack(fill=tk.X, padx=10, pady=(0,10))
        
        self.set_price_button = ttk.Button(self.bottom_frame, text="⚙⚙ 设置单价", 
                                         style='Settings.TButton',
                                         command=self.open_price_setting)
        self.set_price_button.pack(side=tk.RIGHT, padx=5, pady=5)
        
        self.tare_button = ttk.Button(self.bottom_frame, text="去皮", 
                                    style='Settings.TButton',
                                    command=self.tare_sensor)
        self.tare_button.pack(side=tk.RIGHT, padx=5, pady=5)
        
        self.version_label = ttk.Label(self.bottom_frame, text="v1.0 © 2023 智能果蔬系统",
                                     style='Hint.TLabel')
        self.version_label.pack(side=tk.LEFT, padx=5)
    
    def update_time(self):
        current_time = time.strftime("%Y-%m-%d %H:%M:%S")
        self.time_label.config(text=current_time)
        self.root.after(1000, self.update_time)
    
    def preprocess(self, frame):
        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w = frame_rgb.shape[:2]
        
        # 计算缩放比例
        scale = min(640 / h, 640 / w)
        new_h, new_w = int(h * scale), int(w * scale)
        
        # 缩放图像
        resized = cv2.resize(frame_rgb, (new_w, new_h), interpolation=cv2.INTER_LINEAR)
        
        # 创建画布并填充
        canvas = np.full((640, 640, 3), 128, dtype=np.uint8)
        top = (640 - new_h) // 2
        left = (640 - new_w) // 2
        canvas[top:top+new_h, left:left+new_w] = resized
        
        input_tensor = canvas.astype(np.float32) / 255.0
        input_tensor = input_tensor.transpose(2, 0, 1)  # HWC to CHW
        
        return input_tensor[np.newaxis, ...], (scale, top, left)
    
    def postprocess(self, detections, conf_threshold=0.1):
        detections = detections[0]
        mask = detections[:, 4] > conf_threshold
        return detections[mask]
    
    def draw_detections(self, frame, detections, scale, top, left):
        if len(detections) == 0:
            return frame
        
        h, w = frame.shape[:2]
        
        for det in detections:
            x_min, y_min, x_max, y_max, conf, cls_id = det
            
            x_min = int((x_min - left) / scale)
            y_min = int((y_min - top) / scale)
            x_max = int((x_max - left) / scale)
            y_max = int((y_max - top) / scale)
            
            x_min = max(0, min(x_min, w - 1))
            y_min = max(0, min(y_min, h - 1))
            x_max = max(0, min(x_max, w - 1))
            y_max = max(0, min(y_max, h - 1))
            
            if x_max > x_min and y_max > y_min:
                # 绘制边界框
                cv2.rectangle(frame, (x_min, y_min), (x_max, y_max), (0, 255, 0), 2)
                
                # 获取类别ID和置信度
                cls_id = int(det[5])
                conf = det[4]
                
                if cls_id < 0 or cls_id >= len(self.classes):
                    continue
                    
                # 使用中文类别名称
                class_name = self.classes[cls_id]
                label = f"{class_name} {conf:.2f}"

                (text_w, text_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.7, 2)

                label_y = y_min - 10 if y_min > 30 else y_max + 20
                label_y = min(max(label_y, 20), h - 10)

                cv2.rectangle(frame, 
                             (x_min, label_y - text_h - 5),
                             (x_min + text_w, label_y + 5),
                             (0, 255, 0), -1)

                cv2.putText(frame, label, (x_min, label_y), 
                           cv2.FONT_HERSHEY_SIMPLEX, 0.7, (0, 0, 0), 1)
        
        return frame
    
    def update_camera(self):

        try:
            ret, frame = self.cap.read()
            if ret:
                self.frame_count += 1
                
                # 进行物体检测
                if self.model_loaded:
                    # 预处理
                    input_tensor, (scale, top, left) = self.preprocess(frame)
                    
                    # 推理
                    detections = self.sess.run([self.output_name], {self.input_name: input_tensor})[0]
                    
                    # 后处理
                    results = self.postprocess(detections, conf_threshold=0.1)
                    
                    # 如果有检测结果，更新当前物品
                    if len(results) > 0:
                        # 取置信度最高的结果
                        best_det = max(results, key=lambda x: x[4])
                        cls_id = int(best_det[5])
                        
                        # 确保类别ID在有效范围内
                        if 0 <= cls_id < len(self.classes):
                            self.current_item = self.classes[cls_id]
                    
                    # 绘制检测结果
                    frame = self.draw_detections(frame, results, scale, top, left)
                
                # 计算并显示FPS
                elapsed_time = time.time() - self.start_time
                fps = self.frame_count / elapsed_time if elapsed_time > 0 else 0
                cv2.putText(frame, f"FPS: {fps:.1f}", (10, 30), 
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                
                # 显示图像
                self.display_image(frame)
            
            # 根据FPS动态调整更新频率
            self.root.after(100, self.update_camera)
        except Exception:
            self.root.after(100, self.update_camera)
    
    def display_image(self, frame):
        try:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            img = Image.fromarray(frame)
            
            # 获取Canvas尺寸
            canvas_width = self.canvas.winfo_width()
            canvas_height = self.canvas.winfo_height()
            
            if canvas_width > 0 and canvas_height > 0:
                # 计算缩放比例
                img_ratio = img.width / img.height
                canvas_ratio = canvas_width / canvas_height
                
                if img_ratio > canvas_ratio:
                    new_width = canvas_width
                    new_height = int(canvas_width / img_ratio)
                else:
                    new_height = canvas_height
                    new_width = int(canvas_height * img_ratio)
                
                # 缩放图像
                img = img.resize((new_width, new_height), Image.BILINEAR)
                
                # 创建PhotoImage并显示
                imgtk = ImageTk.PhotoImage(image=img)
                
                # 清除Canvas并显示新图像
                self.canvas.delete("all")
                self.canvas.create_image(canvas_width//2, canvas_height//2, 
                                        anchor=tk.CENTER, image=imgtk)
                self.canvas.image = imgtk
        except Exception:
            pass
    
    def update_weight(self):
        try:
            # 从传感器读取重量（单位：克）
            weight_grams = self.sensor.get_weight(times=3) if self.sensor else random.uniform(0.1, 2.5) * 1000
            
            # 转换为千克
            weight_kg = weight_grams / 1000
            
            # 忽略微小重量（去皮后可能存在的小误差）
            if weight_kg < 0.005:  # 小于5克视为0
                weight_kg = 0.0
            
            self.weight = weight_kg
            
            # 如果有当前物品，则更新价格
            if self.current_item and self.weight > 0:
                # 确保当前物品在价格字典中
                price = self.items.get(self.current_item, 10.0)
                self.total_price = round(price * self.weight, 2)
                
                self.item_label.config(text=f"品类：{self.current_item}")
                self.price_label.config(text=f"单价：{price:.2f} 元/kg")
                self.weight_label.config(text=f"重量：{self.weight:.3f} kg")
                self.total_label.config(text=f"总价：{self.total_price:.2f} 元")
            else:
                self.total_price = 0.0
                
                self.item_label.config(text="品类：未识别")
                self.price_label.config(text="单价：0.00 元/kg")
                self.weight_label.config(text=f"重量：{self.weight:.3f} kg")
                self.total_label.config(text="总价：0.00 元")
            
            # 降低更新频率（2秒）
            self.root.after(2000, self.update_weight)
        except Exception:
            self.root.after(2000, self.update_weight)
    
    def tare_sensor(self):
        if self.sensor:
            self.sensor.tare()
            messagebox.showinfo("去皮操作", "去皮操作已完成，重量已归零")
        else:
            messagebox.showwarning("警告", "称重传感器不可用")
    
    def process_payment(self):
        if self.current_item is None:
            messagebox.showwarning("提示", "未检测到商品，请放置商品后再支付")
            return
        
        pay_window = tk.Toplevel(self.root)
        pay_window.title("支付成功")
        pay_window.geometry("300x200")
        pay_window.resizable(False, False)
        
        # 居中窗口
        x = self.root.winfo_x() + (self.root.winfo_width() - 300) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 200) // 2
        pay_window.geometry(f"+{x}+{y}")
        
        ttk.Label(pay_window, text="✓", font=('Arial', 40, 'bold'),
                 foreground='#2ecc71').pack(pady=10)
        ttk.Label(pay_window, text="支付成功!", 
                 font=('Microsoft YaHei', 14, 'bold')).pack()
        ttk.Label(pay_window, 
                 text=f"商品: {self.current_item}\n重量: {self.weight:.3f}kg\n总价: {self.total_price:.2f}元",
                 font=('Microsoft YaHei', 11)).pack(pady=10)
        
        ttk.Button(pay_window, text="确定", command=pay_window.destroy,
                  style='Accent.TButton').pack(pady=10)
        
        # 重置状态
        self.current_item = None
        self.weight = 0.0
        self.total_price = 0.0
    
    def open_price_setting(self):
        setting_window = tk.Toplevel(self.root)
        setting_window.title("设置商品单价")
        setting_window.geometry("400x500")
        setting_window.resizable(False, False)
        
        # 居中窗口
        x = self.root.winfo_x() + (self.root.winfo_width() - 400) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 500) // 2
        setting_window.geometry(f"+{x}+{y}")
        
        setting_window.configure(bg='#f5f5f5')
        
        ttk.Label(setting_window, text="商品单价设置", 
                 style='Title.TLabel').pack(pady=10)
        
        price_entries = {}
        for item, price in self.items.items():
            frame = ttk.Frame(setting_window, style='Custom.TFrame')
            frame.pack(fill=tk.X, padx=20, pady=8)
            
            ttk.Label(frame, text=item, width=10, 
                    style='Info.TLabel').pack(side=tk.LEFT)
            
            entry = ttk.Entry(frame, font=('Microsoft YaHei', 11))
            entry.insert(0, f"{price:.2f}")
            entry.pack(side=tk.RIGHT, expand=True, fill=tk.X, ipady=3)
            price_entries[item] = entry
        
        def save_prices():
            for item, entry in price_entries.items():
                try:
                    new_price = float(entry.get())
                    self.items[item] = new_price
                except ValueError:
                    messagebox.showerror("错误", f"请输入有效的价格: {item}")
                    return
            
            save_label = ttk.Label(setting_window, text="✓ 单价已更新", 
                                 foreground='#2ecc71', font=('Microsoft YaHei', 10))
            save_label.pack()
            setting_window.after(1500, save_label.destroy)
        
        btn_frame = ttk.Frame(setting_window, style='Custom.TFrame')
        btn_frame.pack(fill=tk.X, pady=10)
        
        ttk.Button(btn_frame, text="保存", style='Accent.TButton',
                  command=save_prices).pack(side=tk.RIGHT, padx=20, ipadx=20)
        
        ttk.Button(btn_frame, text="取消", style='Settings.TButton',
                  command=setting_window.destroy).pack(side=tk.RIGHT, ipadx=20)
    
    def __del__(self):
        """释放摄像头资源"""
        if hasattr(self, 'cap') and self.cap.isOpened():
            self.cap.release()

if __name__ == "__main__":
    root = tk.Tk()
    try:
        icon_path = os.path.abspath('fruit_icon.ico')
        if os.path.exists(icon_path):
            root.iconbitmap(icon_path)
    except Exception:
        pass
    
    app = FruitVegScaleApp(root)
    root.mainloop()